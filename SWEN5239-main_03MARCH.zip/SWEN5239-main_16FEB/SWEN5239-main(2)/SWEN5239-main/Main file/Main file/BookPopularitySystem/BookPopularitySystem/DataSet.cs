﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookPopularitySystem
{
    public class DataSet
    {
        //Id,Book Title,Book Rating,Author Overall Rating,Genre,Format,Availability ,Number of Reviews

        public string ID { get; set; }
        public string BookTitle { get; set; }
        public string BookRating { get; set; }
        public string AuthorOverallRating { get; set; }
        public string Genre { get; set; }
        public string Format { get; set; }
        public string Availability { get; set; }
        public string NumberOfReviews { get; set; }
       

    }
}
