﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        // browse for file button
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();
            textBox1.Text = dlg.FileName;
        }

        // load file button
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = LoadCSV(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("A file must be browsed first!");
            }
            
        }

        public List<DataSet> LoadCSV(string csvFile)
        {
            var file = File.ReadAllLines(csvFile);
            var query = from l in file.Skip(1)
                        let data = l.Split(',')
                        select new DataSet
                        {
                            ID = int.Parse(data[0]),
                            BookTitle = data[1],
                            BookRating = double.Parse(data[2]),
                            AuthorOverallRating = double.Parse(data[3]),
                            Genre = data[4],
                            Format = data[5],
                            Availability = bool.Parse(data[6]),
                            NumberOfReviews = int.Parse(data[7])
                        };
            //var orderedQuery = query.OrderByDescending(x => x.BookRating);
            return query.ToList();
        }

        public class DataSet
        {
            //Id,Book Title,Book Rating,Author Overall Rating,Genre,Format,Availability ,Number of Reviews

            public int ID { get; set; }
            public string BookTitle { get; set; }
            public double BookRating { get; set; }
            public double AuthorOverallRating { get; set; }
            public string Genre { get; set; }
            public string Format { get; set; }
            public bool Availability { get; set; }
            public int NumberOfReviews { get; set; }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //button for popular list
        private void button3_Click(object sender, EventArgs e)
        {
            

            try
            {
                var originalQuery = LoadCSV(textBox1.Text);
                var sortedQuery = originalQuery.OrderByDescending(x => x.BookRating).ToList();

                var aboveFour = sortedQuery.Where(x => x.BookRating > 4 && x.AuthorOverallRating > 4 && x.NumberOfReviews > 1000).ToList();
                dataGridView2.DataSource = aboveFour;
            }
            catch (Exception)
            {
                MessageBox.Show("A file must be loaded first!");
            }

            
        }

        //button for unpopular list
        private void button4_Click(object sender, EventArgs e)
        {

            try
            {
                var originalQuery = LoadCSV(textBox1.Text);
                var sortedQuery = originalQuery.OrderBy(x => x.BookRating).ToList();

                var belowFour = sortedQuery.Where(x => x.BookRating < 4 && x.AuthorOverallRating < 4 && x.NumberOfReviews <= 1000).ToList();
                dataGridView2.DataSource = belowFour;
            }
            catch (Exception)
            {
                MessageBox.Show("A file must be loaded first!");
            }
        }

        // availability button
        private void button5_Click(object sender, EventArgs e)
        {

            try
            {
                var originalQuery = LoadCSV(textBox1.Text);
                var sortedQuery = originalQuery.OrderByDescending(x => x.BookRating).ToList();

                var BookAvailability = sortedQuery.Where(x => x.Availability == true).ToList();

                dataGridView2.DataSource = BookAvailability;
            }
            catch (Exception)
            {
                MessageBox.Show("A file must be loaded first!");
            }
        }
    }
}
