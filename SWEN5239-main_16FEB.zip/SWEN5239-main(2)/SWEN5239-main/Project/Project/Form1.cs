﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();
            textBox1.Text = dlg.FileName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = LoadCSV(textBox1.Text);
        }

        public List<DataSet> LoadCSV(string csvFile)
        {
            var file = File.ReadAllLines(csvFile);
            var query = from l in file.Skip(1)
                        let data = l.Split(',')
                        select new DataSet
                        {
                            ID = data[0],
                            BookTitle = data[1],
                            BookRating = data[2],
                            AuthorOverallRating = data[3],
                            Genre = data[4],
                            Format = data[5],
                            Availability = data[6],
                            NumberOfReviews = data[7]
                        };
            return query.ToList();
        }

        public class DataSet
        {
            //Id,Book Title,Book Rating,Author Overall Rating,Genre,Format,Availability ,Number of Reviews

            public string ID { get; set; }
            public string BookTitle { get; set; }
            public string BookRating { get; set; }
            public string AuthorOverallRating { get; set; }
            public string Genre { get; set; }
            public string Format { get; set; }
            public string Availability { get; set; }
            public string NumberOfReviews { get; set; }
        }
    }
}
