﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();
            textBox1.Text = dlg.FileName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = LoadCSV(textBox1.Text);
        }

        public List<DataSet> LoadCSV(string csvFile)
        {
            var file = File.ReadAllLines(csvFile);
            var query = from l in file.Skip(1)
                        let data = l.Split(',')
                        select new DataSet
                        {
                            ID = int.Parse(data[0]),
                            BookTitle = data[1],
                            BookRating = double.Parse(data[2]),
                            AuthorOverallRating = double.Parse(data[3]),
                            Genre = data[4],
                            Format = data[5],
                            Availability = bool.Parse(data[6]),
                            NumberOfReviews = int.Parse(data[7])
                        };
            //var orderedQuery = query.OrderByDescending(x => x.BookRating);
            return query.ToList();
        }

        public class DataSet
        {
            //Id,Book Title,Book Rating,Author Overall Rating,Genre,Format,Availability ,Number of Reviews

            public int ID { get; set; }
            public string BookTitle { get; set; }
            public double BookRating { get; set; }
            public double AuthorOverallRating { get; set; }
            public string Genre { get; set; }
            public string Format { get; set; }
            public bool Availability { get; set; }
            public int NumberOfReviews { get; set; }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var originalQuery = LoadCSV(textBox1.Text);
            var sortedQuery = originalQuery.OrderByDescending(x => x.BookRating).ToList();

            var aboveFour = sortedQuery.Where(x => x.BookRating > 4).ToList();

            dataGridView2.DataSource = aboveFour;
        }
    }
}
