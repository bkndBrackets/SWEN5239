using static System.Windows.Forms.DataFormats;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace BookPopularitySystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using(OpenFileDialog ofd = new OpenFileDialog() {Filter="Text file|*.csv"})
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    List<string> Lines = File.ReadAllLines(ofd.FileName).ToList();
                    List<DataSet> Datasets = new List<DataSet>();
                    for (int i = 0; i < Lines.Count; i++) 
                    {
                        string[] data = Lines[i].Split(',');
                        //Id,Book Title,Book Rating,Author Overall Rating,Genre,Format,Availability�,Number of Reviews
                        Datasets.Add(new DataSet() 
                        { 
                            ID=data[0], 
                            BookTitle = data[1], 
                            BookRating = data[2], 
                            AuthorOverallRating = data[3],
                            Genre = data[4],
                            Format = data[5],
                            Availability = data[6],
                            NumberOfReviews = data[7]

                        });

                       

                    } dataSetBindingSource1.DataSource = Datasets;

                }

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}